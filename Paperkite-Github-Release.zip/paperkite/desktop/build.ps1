# Paperkite桌面 · Windows 一键构建脚本
# 用法（PowerShell）: .\build.ps1
# 前置：Rust (https://rustup.rs) + Tauri CLI (cargo install tauri-cli --version "^2")
#       已装 WebView2 运行时（Win10/11 通常自带）
# 产物: src-tauri\target\release\bundle\nsis\Paperkite桌面_0.1.0_x64-setup.exe

$ErrorActionPreference = "Stop"

Write-Host "=== Paperkite桌面 构建脚本 v0.1.0 ===" -ForegroundColor Cyan

# 1. 检查 Rust
if (-not (Get-Command cargo -ErrorAction SilentlyContinue)) {
    Write-Host "[错误] 未安装 Rust。请先: https://rustup.rs" -ForegroundColor Red
    exit 1
}
Write-Host "[1/4] Rust 工具链 OK: $(cargo --version)" -ForegroundColor Green

# 2. 检查 Tauri CLI
$tauriVer = (cargo tauri --version 2>$null) -join ""
if ([string]::IsNullOrWhiteSpace($tauriVer)) {
    Write-Host "[错误] 未安装 Tauri CLI。请执行: cargo install tauri-cli --version '^2'" -ForegroundColor Red
    exit 1
}
Write-Host "[2/4] Tauri CLI OK: $tauriVer" -ForegroundColor Green

# 3. 检查前端文件
$frontend = Join-Path $PSScriptRoot "frontend\paperkite.html"
if (-not (Test-Path $frontend)) {
    Write-Host "[错误] 缺少前端文件: $frontend" -ForegroundColor Red
    exit 1
}
Write-Host "[3/4] 前端文件 OK: $((Get-Item $frontend).Length) bytes" -ForegroundColor Green

# 4. 构建
Write-Host "[4/4] cargo tauri build (首次编译需数分钟)..." -ForegroundColor Yellow
Push-Location (Join-Path $PSScriptRoot "src-tauri")
try {
    cargo tauri build
} finally {
    Pop-Location
}
if ($LASTEXITCODE -ne 0) {
    Write-Host "[错误] 构建失败，exit=$LASTEXITCODE" -ForegroundColor Red
    exit $LASTEXITCODE
}

# 5. 定位安装包
$installer = Get-ChildItem (Join-Path $PSScriptRoot "src-tauri\target\release\bundle\nsis") -Filter "*.exe" |
    Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $installer) {
    Write-Host "[错误] 未找到 NSIS 安装包" -ForegroundColor Red
    exit 1
}
Write-Host "构建完成 ✓" -ForegroundColor Green
Write-Host "安装包: $($installer.FullName)"
Write-Host "大小: $([math]::Round($installer.Length/1MB, 1)) MB"
Write-Host ""
Write-Host "下一步：在新机器上安装，按 desktop/README.md 的「桌面能力」清单逐项验证"
