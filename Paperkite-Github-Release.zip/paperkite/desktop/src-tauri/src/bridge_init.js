// Paperkite桌面 · 文件桥初始化脚本
// 在页面加载前注入，暴露 window.__PKDESKTOP__ 供前端检测与调用。
// 前端 paperkite.html 只做薄适配：检测 __PKDESKTOP__ 存在 → 基地/导出走桥。

(function () {
  // Tauri 的 invoke 注入（Tauri 2 通过 __TAURI_INTERNALS__ 提供）
  // V2.85.0：X18——非 Tauri 环境注入时优雅失败（原直接取 __TAURI_INTERNALS__.invoke 会 TypeError）
  function invoke(cmd, args) {
    if (!window.__TAURI_INTERNALS__ || typeof window.__TAURI_INTERNALS__.invoke !== "function") {
      return Promise.reject(new Error("当前环境无 Tauri 桥（__TAURI_INTERNALS__ 缺失）"));
    }
    return window.__TAURI_INTERNALS__.invoke(cmd, args || {});
  }
  // 统一错误包装：reject 时带命令名，保留原始错误详情（V2.84.0：W23 修复——原来只留 message 字符串，错误类型/前缀丢失）
  function call(cmd, args) {
    return invoke(cmd, args).catch(function (e) {
      var msg = (e && e.message) || e || "未知错误";
      var err = new Error(cmd + " 失败: " + msg);
      if (e && e !== msg) { try { err.original = e; err.originalMessage = msg; } catch (_) {} }
      throw err;
    });
  }

  window.__PKDESKTOP__ = {
    // 版本信息（壳层注入）
    version: "0.1.0",
    appName: "Paperkite桌面",

    // ---- 基地 ----
    pickBase: function () {
      return call("pick_base").then(function (r) {
        if (r && r.root) {
          // 返回 {root, name}
          return { root: r.root, name: r.name || "" };
        }
        return null; // 用户取消
      });
    },
    restoreBase: function (root) {
      return call("restore_base", root ? { root: root } : {}).then(function (r) {
        if (r && r.root) return { root: r.root, name: r.name || "" };
        return null;
      });
    },
    disconnectBase: function () {
      return call("disconnect_base");
    },

    // ---- 文件系统（路径式，等价 FSA） ----
    // list(path) → [{name,path,isDir,size}]
    list: function (path) {
      return call("fs_list", { path: path || "/" });
    },
    // readText(path) → string
    readText: function (path) {
      return call("fs_read_text", { path: path });
    },
    // writeText(path, text, createDirs)
    writeText: function (path, text, createDirs) {
      return call("fs_write_text", { path: path, text: text, createDirs: !!createDirs });
    },
    // mkdir(path)
    mkdir: function (path) {
      return call("fs_mkdir", { path: path });
    },
    // remove(path, recursive)
    remove: function (path, recursive) {
      return call("fs_remove", { path: path, recursive: !!recursive });
    },

    // ---- 保存文件（弹保存对话框） ----
    // saveFile(suggestedName, content) → 绝对路径 | null（取消）——文本通道
    saveFile: function (suggestedName, content) {
      return call("save_file", { suggestedName: suggestedName, content: content });
    },
    // saveFileBin(suggestedName, base64) → 绝对路径 | null（取消）——二进制通道（V2.86.0 W24：PNG 等二进制导出必走此通道，文本通道会按 UTF-8 损坏字节）
    saveFileBin: function (suggestedName, base64) {
      return call("save_file_b64", { suggestedName: suggestedName, contentB64: base64 });
    },

    // ---- 应用信息 ----
    getInfo: function () {
      return call("get_app_info");
    },
    getDataDir: function () {
      return call("get_data_dir");
    },

    // ---- TTS 控制（壳层联动：托盘/全局快捷键） ----
    // 注意：这些函数由壳层通过 win.eval 调用，故定义为全局可访问
    ttsToggle: function () {
      var fn = (typeof ttsToggle === "function") ? ttsToggle
        : (window.PK && PK.registry && PK.registry.get && PK.registry.get("service", "tts.toggle"));
      if (typeof fn === "function") { fn(); return true; }
      return false;
    },
    ttsPause: function () {
      var fn = (typeof ttsPause === "function") ? ttsPause
        : (window.PK && PK.registry && PK.registry.get && PK.registry.get("service", "tts.pause"));
      if (typeof fn === "function") { fn(); return true; }
      return false;
    },
    ttsStop: function () {
      var fn = (typeof ttsStop === "function") ? ttsStop
        : (window.PK && PK.registry && PK.registry.get && PK.registry.get("service", "tts.stop"));
      if (typeof fn === "function") { fn(); return true; }
      return false;
    },
    ttsIsPlaying: function () {
      // 主路径：全局 ttsState；兜底：PK.core 注册表（与 ttsGetTitle 一致）
      if (typeof ttsState !== "undefined") return !!ttsState.playing;
      if (window.PK && PK.registry && PK.registry.get) {
        var fn = PK.registry.get("service", "tts.isPlaying");
        if (typeof fn === "function") return !!fn();
      }
      return false;
    },
    ttsGetTitle: function () {
      try {
        // 主路径：全局 lsGet + currentBookId；兜底：PK.core 注册表
        var getBooks = (typeof lsGet === "function") ? function () { return lsGet("books_meta", []); }
          : (window.PK && PK.registry && PK.registry.get && PK.registry.get("service", "titles.loadAll"));
        var books = (typeof getBooks === "function") ? getBooks() : [];
        var cur = (typeof currentBookId !== "undefined") ? currentBookId : null;
        if (!cur && window.PK && PK.registry && PK.registry.get) {
          var r = PK.registry.get("service", "reader.currentId");
          if (typeof r === "function") cur = r();
        }
        var b = (books || []).find(function (x) { return x && x.id === cur; });
        return (b && b.title) || "";
      } catch (e) { return ""; }
    },
  };
})();
