use tauri::{AppHandle, Manager};

/// 托盘：后台朗读常驻（最小化/关闭到托盘）
pub fn setup_tray(app: &AppHandle) -> tauri::Result<()> {
    let _ = app;

    #[cfg(target_os = "windows")]
    {
        use tauri::tray::{TrayIconBuilder, TrayIconEvent};
        use tauri::menu::{Menu, MenuItem, PredefinedMenuItem};

        let toggle = MenuItem::with_id(app, "toggle", "播放 / 暂停朗读", true, None::<&str>)?;
        let stop = MenuItem::with_id(app, "stop", "停止朗读", true, None::<&str>)?;
        let sep = PredefinedMenuItem::separator(app)?;
        let show = MenuItem::with_id(app, "show", "显示主窗口", true, None::<&str>)?;
        let quit = MenuItem::with_id(app, "quit", "退出", true, None::<&str>)?;
        let menu = Menu::with_items(app, &[&toggle, &stop, &sep, &show, &quit])?;

        let mut builder = TrayIconBuilder::with_id("main-tray")
            .menu(&menu)
            .tooltip("Paperkite桌面")
            .show_menu_on_left_click(false)
            .on_menu_event(|app, event| match event.id().as_ref() {
                "toggle" => eval_tts(app, "window.__PKDESKTOP__&&window.__PKDESKTOP__.ttsToggle()"),
                "stop" => eval_tts(app, "window.__PKDESKTOP__&&window.__PKDESKTOP__.ttsStop()"),
                "show" => {
                    if let Some(win) = app.get_webview_window("main") {
                        win.show().ok();
                        win.set_focus().ok();
                    }
                }
                "quit" => {
                    // 退出前确认（防误点中断朗读）。托盘菜单事件在主线程派发，
                    // 故用非阻塞 show(callback)——blocking_show 会依赖主线程投递导致死锁。
                    use tauri_plugin_dialog::DialogExt;
                    let handle = app.clone();
                    app.dialog()
                        .message("确定退出 Paperkite 吗？\n若正在朗读，退出会中断朗读。")
                        .title("退出确认")
                        .kind(tauri_plugin_dialog::MessageDialogKind::Warning)
                        .buttons(tauri_plugin_dialog::MessageDialogButtons::OkCancel)
                        .show(move |yes| {
                            if yes {
                                // 进程结束时系统会回收托盘图标，无需手动移除
                                handle.exit(0);
                            }
                        });
                }
                _ => {}
            })
            .on_tray_icon_event(|tray, event| {
                if let TrayIconEvent::Click { button: tauri::tray::MouseButton::Left, .. } = event {
                    if let Some(win) = tray.app_handle().get_webview_window("main") {
                        win.show().ok();
                        win.set_focus().ok();
                    }
                }
            });

        // 图标取打包内嵌的应用图标（原由 tauri.conf.json 的 app.trayIcon 提供；
        // 配置与代码各建一个托盘会出现两个图标，故统一只在此处创建）
        if let Some(icon) = app.default_window_icon() {
            builder = builder.icon(icon.clone());
        }

        // 保留托盘句柄（防 drop 移除）
        let _tray = builder.build(app)?;
    }

    Ok(())
}

/// 在 WebView 里执行 TTS 控制脚本（通过桥对象，前端零侵入）
#[cfg(target_os = "windows")]
fn eval_tts(app: &AppHandle, script: &str) {
    if let Some(win) = app.get_webview_window("main") {
        if let Err(e) = win.eval(script) {
            // 不静默：eval 失败（如页面未加载完）至少留痕到 stderr
            eprintln!("[Paperkite] TTS eval failed: {e}");
        }
    } else {
        eprintln!("[Paperkite] TTS eval skipped: main window not found");
    }
}

