use std::path::{Path, PathBuf};
use std::sync::Mutex;
use tauri::{AppHandle, Manager};
use serde::Serialize;

/// 文件桥：把 paperkite 的 File System Access API 层桥接到 Tauri fs/dialog。
///
/// 设计目标：前端 paperkite.html 零侵入。
/// - 前端 `baseCapable()` 检测 window.__PKDESKTOP__ 存在 → 视为“磁盘基地可用”
/// - 前端 `chooseBase()` 走 __PKDESKTOP__.pickBase()（弹目录选择）
/// - 前端 `diskGetDirHandle/diskList/...` 走 __PKDESKTOP__.fs.*（路径式读写）
/// - 前端 `downloadBlob()` 走 __PKDESKTOP__.saveFile()（弹保存对话框，默认 文档/paperkite/备份）

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct FsEntry {
    pub name: String,
    pub path: String,
    pub is_dir: bool,
    pub size: u64,
}

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BaseState {
    pub root: Option<String>,
    pub name: Option<String>,
}

/// 运行时持有的基地根路径（内存态，会话内有效）
pub struct BaseHolder(pub Mutex<Option<PathBuf>>);

/// 数据根：文档/paperkite
pub fn data_root() -> PathBuf {
    if let Ok(d) = std::env::var("PAPERKITE_DATA_DIR") {
        return PathBuf::from(d);
    }
    if let Some(docs) = dirs::document_dir() {
        return docs.join("paperkite");
    }
    std::env::current_dir().unwrap_or_else(|_| PathBuf::from(".")).join("paperkite")
}

/// 备份/导出默认目录：文档/paperkite/备份
pub fn backup_dir() -> PathBuf {
    data_root().join("备份")
}

/// 规范化相对路径（防 .. 逃逸）：输入 '/入库/a.txt' → '入库/a.txt'
fn safe_rel(path: &str) -> Option<PathBuf> {
    let trimmed = path.trim_start_matches('/');
    if trimmed.is_empty() {
        return Some(PathBuf::new());
    }
    let p = Path::new(trimmed);
    if p.components().any(|c| matches!(c, std::path::Component::ParentDir | std::path::Component::RootDir | std::path::Component::Prefix(_))) {
        return None; // 拒绝 .. 或绝对路径
    }
    Some(p.to_path_buf())
}

/// 把前端逻辑路径（'/' 根）映射到磁盘绝对路径
fn resolve(root: &Path, path: &str) -> Result<PathBuf, String> {
    let rel = safe_rel(path).ok_or("非法路径")?;
    Ok(root.join(rel))
}

// ─── Tauri 命令 ───

/// 前端调用：选择/连接基地目录
/// 注：必须为 async 命令。同步命令在 Tauri 里跑在主线程，而 blocking_pick_folder 内部
/// 依赖 run_on_main_thread 投递对话框，主线程被阻塞即死锁（插件文档亦要求 blocking API 用于异步命令）。
#[tauri::command]
pub async fn pick_base(app: AppHandle) -> Result<BaseState, String> {
    use tauri_plugin_dialog::DialogExt;
    let dir = app.dialog().file().blocking_pick_folder();
    let Some(dir) = dir else {
        return Ok(BaseState { root: None, name: None }); // 用户取消
    };
    let path = dir.into_path().map_err(|e| e.to_string())?;
    let name = path.file_name().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
    let root = Some(path.clone());
    *app.state::<BaseHolder>().0.lock().unwrap_or_else(|e| e.into_inner()) = root.clone();
    Ok(BaseState { root: root.map(|p| p.display().to_string()), name: Some(name) })
}

/// 前端调用：恢复上次连接的基地。
/// - 传 root：把该磁盘路径重新挂为基地（内存态不跨进程，应用重启后前端从 IndexedDB 取回上次路径再调用）
/// - 不传 root：返回当前内存态基地（同进程内）
#[tauri::command]
pub async fn restore_base(app: AppHandle, root: Option<String>) -> Result<BaseState, String> {
    let holder = app.state::<BaseHolder>();
    if let Some(r) = root {
        let path = PathBuf::from(&r);
        if !path.is_dir() {
            *holder.0.lock().unwrap_or_else(|e| e.into_inner()) = None;
            return Ok(BaseState { root: None, name: None });
        }
        let name = path.file_name().map(|s| s.to_string_lossy().to_string());
        *holder.0.lock().unwrap_or_else(|e| e.into_inner()) = Some(path.clone());
        return Ok(BaseState { root: Some(path.display().to_string()), name });
    }
    let current = holder.0.lock().unwrap_or_else(|e| e.into_inner()).clone();
    let name = current.as_ref().and_then(|p| p.file_name()).map(|s| s.to_string_lossy().to_string());
    Ok(BaseState { root: current.map(|p| p.display().to_string()), name })
}

/// 前端调用：断开基地
#[tauri::command]
pub async fn disconnect_base(app: AppHandle) -> Result<(), String> {
    *app.state::<BaseHolder>().0.lock().unwrap_or_else(|e| e.into_inner()) = None;
    Ok(())
}

/// 前端调用：列出目录（等价 diskList）
#[tauri::command]
pub async fn fs_list(app: AppHandle, path: String) -> Result<Vec<FsEntry>, String> {
    let holder = app.state::<BaseHolder>();
    let root = holder.0.lock().unwrap_or_else(|e| e.into_inner()).clone().ok_or("基地未连接")?;
    let abs = resolve(&root, &path).map_err(|e| e.to_string())?;
    if !abs.exists() {
        // 目录不存在：返回特定错误前缀，前端据此触发自动创建
        return Err(format!("PKDIR_NOT_FOUND: {}", abs.display()));
    }
    let rd = std::fs::read_dir(&abs).map_err(|e| e.to_string())?;
    let mut out = Vec::new();
    for entry in rd {
        let entry = entry.map_err(|e| e.to_string())?;
        let ft = entry.file_type().map_err(|e| e.to_string())?;
        let name = entry.file_name().to_string_lossy().to_string();
        let size = if ft.is_dir() { 0 } else { entry.metadata().map(|m| m.len()).unwrap_or(0) };
        // rel 统一以 / 开头（与前端 diskList 的 path 语义一致：/入库/xxx）
        let base = if path == "/" { String::new() } else { path.trim_end_matches('/').to_string() };
        let rel = if base.is_empty() {
            format!("/{}", name)
        } else {
            format!("/{}/{}", base.trim_start_matches('/'), name)
        };
        out.push(FsEntry { name, path: rel, is_dir: ft.is_dir(), size });
    }
    out.sort_by(|a, b| b.is_dir.cmp(&a.is_dir).then(a.name.cmp(&b.name)));
    Ok(out)
}

/// 前端调用：读文件文本（等价 getFileHandle + getFile + text）
/// V2.84.0：W19——非 UTF-8 文件用 lossy 保底（不炸），GBK 真解码留待桥 v0.2 返回 bytes 由前端 pkDecodeText 处理
#[tauri::command]
pub async fn fs_read_text(app: AppHandle, path: String) -> Result<String, String> {
    let holder = app.state::<BaseHolder>();
    let root = holder.0.lock().unwrap_or_else(|e| e.into_inner()).clone().ok_or("基地未连接")?;
    let abs = resolve(&root, &path).map_err(|e| e.to_string())?;
    let bytes = std::fs::read(&abs).map_err(|e| e.to_string())?;
    Ok(String::from_utf8_lossy(&bytes).into_owned())
}

/// 前端调用：写文件文本（等价 getFileHandle(create) + createWritable + write）
/// create_dirs: 自动创建父目录（toBase 的子目录）
#[tauri::command]
pub async fn fs_write_text(app: AppHandle, path: String, text: String, create_dirs: Option<bool>) -> Result<(), String> {
    let holder = app.state::<BaseHolder>();
    let root = holder.0.lock().unwrap_or_else(|e| e.into_inner()).clone().ok_or("基地未连接")?;
    let abs = resolve(&root, &path).map_err(|e| e.to_string())?;
    if create_dirs.unwrap_or(false) {
        if let Some(parent) = abs.parent() {
            std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        }
    }
    std::fs::write(&abs, text).map_err(|e| e.to_string())
}

/// 前端调用：新建目录 / 新建空文件
#[tauri::command]
pub async fn fs_mkdir(app: AppHandle, path: String) -> Result<(), String> {
    let holder = app.state::<BaseHolder>();
    let root = holder.0.lock().unwrap_or_else(|e| e.into_inner()).clone().ok_or("基地未连接")?;
    let abs = resolve(&root, &path).map_err(|e| e.to_string())?;
    std::fs::create_dir_all(&abs).map_err(|e| e.to_string())
}

/// 前端调用：删除（目录递归）
/// V2.85.0：X16——拒绝删除基地根（path 归一化为空时返回 Err，防误删整棵书库）
#[tauri::command]
pub async fn fs_remove(app: AppHandle, path: String, recursive: Option<bool>) -> Result<(), String> {
    let holder = app.state::<BaseHolder>();
    let root = holder.0.lock().unwrap_or_else(|e| e.into_inner()).clone().ok_or("基地未连接")?;
    if path.trim_matches('/').is_empty() {
        return Err("拒绝删除基地根目录".to_string());
    }
    let abs = resolve(&root, &path).map_err(|e| e.to_string())?;
    let meta = std::fs::metadata(&abs).map_err(|e| e.to_string())?;
    if meta.is_dir() {
        if recursive.unwrap_or(false) {
            std::fs::remove_dir_all(&abs).map_err(|e| e.to_string())?;
        } else {
            std::fs::remove_dir(&abs).map_err(|e| e.to_string())?;
        }
    } else {
        std::fs::remove_file(&abs).map_err(|e| e.to_string())?;
    }
    Ok(())
}

/// 前端调用：保存文件（弹保存对话框，默认 文档/paperkite/备份）
/// 返回保存到的绝对路径（用户取消返回 None）
/// 注：async 命令（同 pick_base）——同步命令在主线程调用 blocking_save_file 会死锁。
#[tauri::command]
pub async fn save_file(app: AppHandle, suggested_name: String, content: String) -> Result<Option<String>, String> {
    use tauri_plugin_dialog::DialogExt;
    std::fs::create_dir_all(backup_dir()).map_err(|e| e.to_string())?;
    let path = app.dialog()
        .file()
        .set_file_name(suggested_name.as_str())
        .set_directory(&backup_dir())
        .blocking_save_file();
    let Some(p) = path else { return Ok(None) };
    let abs = p.into_path().map_err(|e| e.to_string())?;
    std::fs::write(&abs, content).map_err(|e| e.to_string())?;
    Ok(Some(abs.display().to_string()))
}

/// 前端调用：保存二进制文件（base64 通道，弹保存对话框，默认 文档/paperkite/备份）
/// V2.86.0：W24——前端 downloadBlob 对 PNG 截图/笔记卡片等二进制导出走此命令（原 save_file 文本通道按 UTF-8 写回会损坏二进制）
/// 返回保存到的绝对路径（用户取消返回 None）
#[tauri::command]
pub async fn save_file_b64(app: AppHandle, suggested_name: String, content_b64: String) -> Result<Option<String>, String> {
    use base64::Engine;
    use tauri_plugin_dialog::DialogExt;
    let bytes = base64::engine::general_purpose::STANDARD
        .decode(content_b64.as_bytes())
        .map_err(|e| format!("base64 解码失败: {e}"))?;
    std::fs::create_dir_all(backup_dir()).map_err(|e| e.to_string())?;
    let path = app.dialog()
        .file()
        .set_file_name(suggested_name.as_str())
        .set_directory(&backup_dir())
        .blocking_save_file();
    let Some(p) = path else { return Ok(None) };
    let abs = p.into_path().map_err(|e| e.to_string())?;
    std::fs::write(&abs, &bytes).map_err(|e| e.to_string())?;
    Ok(Some(abs.display().to_string()))
}
