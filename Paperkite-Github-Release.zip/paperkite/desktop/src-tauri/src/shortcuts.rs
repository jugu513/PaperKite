use tauri::{AppHandle, Manager};
use tauri_plugin_global_shortcut::{Code, GlobalShortcutExt, Modifiers, Shortcut, ShortcutState};

/// 注册全局快捷键（系统级，应用失焦也生效）
/// - Alt+Shift+P 显示/隐藏主窗口
/// - Alt+Shift+Space 播放/暂停朗读（TTS）
/// 说明：不用 Ctrl+Shift+Space（中文 Windows 常被输入法占用）与 Ctrl+Shift+P（打印冲突）。
pub fn setup_shortcuts(app: &AppHandle) -> Result<(), Box<dyn std::error::Error>> {
    // 显示/隐藏主窗口
    let toggle_win = Shortcut::new(Some(Modifiers::ALT | Modifiers::SHIFT), Code::KeyP)?;
    // V2.85.0：X13——注册失败降级（原 ? 传播致应用启动失败；快捷键冲突不应阻止应用运行）
    if let Err(e) = app.global_shortcut().on_shortcut(toggle_win, move |app, _shortcut, event| {
        match event.state {
            ShortcutState::Pressed => {
                if let Some(win) = app.get_webview_window("main") {
                    // V2.84.0：W22——最小化时 is_visible 仍 true，需单独恢复（否则快捷键隐藏而非显示）
                    if win.is_minimized().unwrap_or(false) {
                        win.unminimize().ok();
                        win.set_focus().ok();
                    } else if win.is_visible().unwrap_or(false) {
                        win.hide().ok();
                    } else {
                        win.show().ok();
                        win.set_focus().ok();
                    }
                }
            }
            ShortcutState::Released => {}
        }
    }) {
        eprintln!("[Paperkite] Alt+Shift+P shortcut register failed: {e}");
    }

    // 播放/暂停朗读（走前端 TTS 桥）
    let toggle_tts = Shortcut::new(Some(Modifiers::ALT | Modifiers::SHIFT), Code::Space)?;
    if let Err(e) = app.global_shortcut().on_shortcut(toggle_tts, move |app, _shortcut, event| {
        match event.state {
            ShortcutState::Pressed => {
                if let Some(win) = app.get_webview_window("main") {
                    if let Err(e) = win.eval("window.__PKDESKTOP__&&window.__PKDESKTOP__.ttsToggle()") {
                        // 不静默：快捷键 TTS eval 失败留痕（与托盘 eval_tts 一致）
                        eprintln!("[Paperkite] shortcut TTS eval failed: {e}");
                    }
                }
            }
            ShortcutState::Released => {}
        }
    }) {
        eprintln!("[Paperkite] Alt+Shift+Space shortcut register failed: {e}");
    }

    Ok(())
}
