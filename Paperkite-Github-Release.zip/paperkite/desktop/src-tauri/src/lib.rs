use std::path::PathBuf;
use tauri::{Manager, WebviewUrl, WebviewWindowBuilder};
use tauri_plugin_dialog::DialogExt;
use tauri_plugin_window_state::StateFlags;

mod bridge;
mod shortcuts;
mod tray;

/// 应用显示名
pub const APP_NAME: &str = "Paperkite桌面";
/// 桌面版独立版本号（与前端 PK.version=v1.7.0 分离）
pub const APP_VERSION: &str = "0.1.0";
/// V2.85.0：X12——前端版本提为常量（原硬编码在 get_app_info，升级前端易漏改导致关于页版本错）
pub const FRONTEND_VERSION: &str = "1.7.0";

/// 数据目录：文档/paperkite/WebView2（WebView2 专用，localStorage/IDB/OPFS 落这里）
/// 注意：与 bridge.rs 的 data_root() 不同——后者是数据根（文档/paperkite），
/// 本函数返回的是「WebView2 用户数据子目录」（文档/paperkite/WebView2）。
/// PAPERKITE_DATA_DIR 环境变量是「数据根」，此处 join 出 WebView2 子目录。
fn data_dir() -> PathBuf {
    if let Ok(d) = std::env::var("PAPERKITE_DATA_DIR") {
        return PathBuf::from(d).join("WebView2");
    }
    if let Some(docs) = dirs::document_dir() {
        return docs.join("paperkite").join("WebView2");
    }
    // 兜底：当前目录
    std::env::current_dir().unwrap_or_else(|_| PathBuf::from(".")).join("paperkite").join("WebView2")
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let builder = tauri::Builder::default()
        .plugin(tauri_plugin_single_instance::init(|app, _args, _cwd| {
            // 第二个实例启动时：唤回主窗口
            if let Some(win) = app.get_webview_window("main") {
                win.show().ok();
                win.set_focus().ok();
            }
        }))
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_global_shortcut::Builder::new().build())
        .plugin(
            tauri_plugin_window_state::Builder::default()
                .with_state_flags(StateFlags::all())
                .build(),
        )
        .manage(bridge::BaseHolder(std::sync::Mutex::new(None)))
        .invoke_handler(tauri::generate_handler![
            get_app_info,
            get_data_dir,
            bridge::pick_base,
            bridge::restore_base,
            bridge::disconnect_base,
            bridge::fs_list,
            bridge::fs_read_text,
            bridge::fs_write_text,
            bridge::fs_mkdir,
            bridge::fs_remove,
            bridge::save_file,
            bridge::save_file_b64
        ])
        .setup(|app| {
            // ---- 数据目录 ----
            let data = data_dir();
            // V2.85.0：X11——创建失败留痕（原 .ok() 静默，失败会让 WebView2 落不进去）
            if let Err(e) = std::fs::create_dir_all(&data) {
                eprintln!("[Paperkite] data dir create failed: {e}");
            }
            // WebView2 用户数据目录：真正生效的是下方 .data_directory()（窗口 build 时传入）。
            // 环境变量 WEBVIEW2_USER_DATA_FOLDER 仅为早期初始化兜底（若 Tauri 在 setup 前建环境，
            // 此处 set_var 对已建环境无效但无害）。
            std::env::set_var("WEBVIEW2_USER_DATA_FOLDER", &data);
            println!("[Paperkite] WebView2 data dir: {}", data.display());

            // ---- 主窗口 ----
            // WebView2 后台定时器防节流（息屏朗读需要 setInterval 不被节流）
            // Tauri 通过 WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS 传给 WebView2 运行时
            // 注：edition 2021 下 set_var 为安全函数，无需 unsafe（升级 edition 2024 时需改回）
            {
                let existing = std::env::var("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS").unwrap_or_default();
                if !existing.contains("disable-background-timer-throttling") {
                    let merged = if existing.is_empty() {
                        "--disable-background-timer-throttling".to_string()
                    } else {
                        format!("{} --disable-background-timer-throttling", existing)
                    };
                    std::env::set_var("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", merged);
                }
            }

            // 注入文件桥：window.__PKDESKTOP__（前端检测此对象启用桌面能力）
            // 用 initialization_script 在页面加载前注入
            let bridge_script = include_str!("bridge_init.js");

            // V2.85.0：X10——build 失败（如系统缺 WebView2）不 panic 崩溃，降级提示后退出
            let win = match WebviewWindowBuilder::new(
                app,
                "main",
                WebviewUrl::App("paperkite.html".into()),
            )
            .initialization_script(bridge_script)
            .title(format!("{} v{}", APP_NAME, APP_VERSION))
            .inner_size(1280.0, 800.0)
            .min_inner_size(940.0, 600.0)
            .resizable(true)
            .center()
            // 关键：把 WebView2 用户数据目录指到 文档/paperkite/WebView2
            // （localStorage/IndexedDB/OPFS 全落此目录，用户可见可备份）
            .data_directory(data.clone())
            .build() {
                Ok(w) => w,
                Err(e) => {
                    eprintln!("[Paperkite] main window build failed: {e}");
                    // 弹错误对话框提示（WebView2 缺失是常见原因）。
                    // setup 在主线程执行，blocking_show 会死锁，改用非阻塞 show，关闭对话框后退出。
                    let handle = app.handle().clone();
                    app.dialog()
                        .message(format!("窗口创建失败：{e}\n\n若系统缺少 WebView2 运行时，请安装 Microsoft Edge WebView2 Runtime 后重试。"))
                        .title("Paperkite 启动失败")
                        .show(move |_| {
                            handle.exit(1);
                        });
                    return Ok(());
                }
            };

            // 关闭到托盘：点 X 不退出，隐藏到托盘（后台朗读不中断）
            {
                let win_handle = win.clone();
                win.on_window_event(move |event| {
                    if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                        // 隐藏而非退出（托盘常驻）
                        api.prevent_close();
                        let _ = win_handle.hide();
                    }
                });
                // win 本体已由 Tauri 运行时持有（on_window_event 注册的闭包用 win_handle 副本），
                // 此处显式 drop 本地句柄，消除 unused variable 警告并明确意图
                drop(win);
            }
            // 托盘退出菜单用 app.exit() 真退出

            // ---- 托盘 ----
            tray::setup_tray(app.handle())?;

            // ---- 全局快捷键 ----
            shortcuts::setup_shortcuts(app.handle())?;

            // 窗口状态恢复由 window-state 插件自动处理（无需手动钩子）

            Ok(())
        });

    builder
        .build(tauri::generate_context!())
        .expect("error while building paperkite desktop")
        .run(|_app_handle, _event| {
            // 系统退出路径（关机/注销/托盘 quit）默认不阻止（Tauri 不 prevent 即放行）。
            // 用户点 X / Alt+F4 走窗口 CloseRequested → 隐藏到托盘（见 setup），
            // 不触发 ExitRequested，两条路径互不干扰。
        });
}

/// 前端获取应用信息（版本线分离：壳层注入，前端 PK.version 不动）
#[tauri::command]
fn get_app_info() -> serde_json::Value {
    serde_json::json!({
        "name": APP_NAME,
        "version": APP_VERSION,
        "frontendVersion": FRONTEND_VERSION,
    })
}

/// 前端获取数据目录（用于“打开数据目录”等功能）
#[tauri::command]
fn get_data_dir() -> String {
    data_dir().display().to_string()
}
