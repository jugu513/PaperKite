# Paperkite桌面 · Windows 桌面壳

Paperkite 阅读器的 Windows 桌面版（Tauri 2.x / WebView2 内核，安装包约 3MB）。

## 结构

```
src-tauri/
  Cargo.toml         Rust 依赖清单（tauri 2.x + 插件）
  tauri.conf.json    应用配置：名称/窗口/构建
  build.rs           Tauri 构建脚本
  capabilities/default.json  权限声明
  icons/             应用图标
  src/
    main.rs          入口（调用 lib）
    lib.rs           核心逻辑：窗口/数据目录/托盘/快捷键/桥注册
    bridge.rs        文件桥：基地 + 文件系统 + 保存（Tauri 命令）
    bridge_init.js   桥初始化脚本（注入 window.__PKDESKTOP__）
    tray.rs          托盘菜单
    shortcuts.rs     全局快捷键
  frontend/
    paperkite.html   前端（与仓库根目录 HTML 版同步）
```

## 构建（需 Windows + Rust 工具链）

```bash
# 安装 Rust: https://rustup.rs
rustup default stable
# 安装 WebView2 运行时（Win10/11 通常自带）
# 构建
cargo tauri build
# 产物: src-tauri/target/release/bundle/nsis/Paperkite桌面_0.1.0_x64-setup.exe
```

或用 `desktop` 目录下的一键脚本：`powershell .\desktop\build.ps1`

## 数据目录

`文档/paperkite/WebView2` — WebView2 data_directory 指向此处
localStorage / IndexedDB / OPFS 数据全部落在这里，用户可见可备份。
备份/导出默认保存位置：`文档/paperkite/备份`

## 桌面能力

| 能力 | 实现 |
|---|---|
| 托盘后台朗读 | 托盘菜单：播放/暂停朗读、停止朗读、显示主窗口、退出（经桥调前端 TTS） |
| 关闭到托盘 | 点 X 拦截 CloseRequested → 隐藏窗口（朗读不中断），托盘退出菜单真退出 |
| 全局快捷键 | Alt+Shift+P 显示/隐藏窗口；Alt+Shift+Space 播放/暂停朗读 |
| 单实例 | tauri-plugin-single-instance：二次启动唤回主窗口 |
| SMTC 任务栏媒体控制 | 前端 MediaSession（WebView2 自动映射） |
| 后台定时器防节流 | --disable-background-timer-throttling 已注入（息屏朗读不挂起） |

> **关闭行为**：点 X 或 Alt+F4 都会隐藏到托盘（后台朗读不中断），退出请用托盘菜单「退出」。这是有意设计（阅读应用常驻）。

## 文件桥

把 paperkite 前端的 File System Access API 层桥接到 Tauri fs/dialog：

| 前端能力 | 浏览器（HTML 版） | 桌面（桥） |
|---|---|---|
| 基地连接 | showDirectoryPicker | __PKDESKTOP__.pickBase（原生目录对话框） |
| 基地遍历 | FileSystemDirectoryHandle | __PKDESKTOP__.list / readText / writeText |
| 基地增删 | getDirectoryHandle/removeEntry | __PKDESKTOP__.mkdir / remove |
| 备份写入 | createWritable | __PKDESKTOP__.writeText（自动建目录） |
| 下载/导出 | a.click + objectURL | __PKDESKTOP__.saveFile（保存对话框，默认文档/paperkite/备份） |
| 二进制导出（PNG 截图等） | a.click + objectURL | __PKDESKTOP__.saveFileBin（base64 通道，字节精确；文本导出走 saveFile） |

桥对象另有 TTS 控制：`__PKDESKTOP__.ttsToggle() / ttsPause() / ttsStop() / ttsIsPlaying() / ttsGetTitle()`（壳层经 win.eval 调用，前端零侵入）。

> **基地跨重启恢复**：基地路径存在本地 IndexedDB，重启后自动把该路径回传壳层重新挂载（`__PKDESKTOP__.restoreBase(path)`）；目录已被删除则提示重新选择。

前端改动全部是**薄适配**：检测 `window.__PKDESKTOP__` 存在则走桥，否则回落浏览器原生 API。浏览器里打开 paperkite.html 行为完全不变——同一份前端，双形态共用。

## 版本线

- 桌面版独立版本号：v0.1.0
- 前端 paperkite.html 内 PK.version=v1.7.0（版本线分离，前端升级不影响壳层）
